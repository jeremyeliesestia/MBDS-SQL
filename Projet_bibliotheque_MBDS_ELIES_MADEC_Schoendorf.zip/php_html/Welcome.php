<!DOCTYPE html>
<html lang="fr">

<head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
	<br>
	<br>
	<div style="text-align:center">
		<a href= "CRUD.php" class="btn btn-primary">
			Afficher CRUD
		</a>
        <a href= "Recherche.php" class="btn btn-primary">
			Afficher recherche
		</a>
	</div>

    <br><br>
    
    <div style="text-align:center">
        <a href= "index.php" class="btn btn-primary">
        Retour
        </a>
    </div>

</body>

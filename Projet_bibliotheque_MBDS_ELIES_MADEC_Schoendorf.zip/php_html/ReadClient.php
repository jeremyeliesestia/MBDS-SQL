<?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
	// Create connection to Oracle
	$conn = oci_connect("SCHOENDORFBZ2223", "SCHOENDORFBZ222301",
	"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");
    
    // Prepare a select statement
	$param_id = Trim($_GET["id"]);
	echo $param_id;
	$stid = oci_parse($conn,'SELECT * FROM CLIENT WHERE ID_CLIENT = :id');

	oci_bind_by_name($stid,":id", $param_id);

	oci_execute($stid);
	
	$row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS);
                
	// Retrieve individual field value
	$id = $row["ID_CLIENT"];
	$nom = $row["NOM"];
	$prenom = $row["PRENOM"];	
	$date_naissance = $row["DATE_DE_NAISSANCE"];	
	$date_inscription = $row["DATE_INSCRIPTION"];	
}     

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-5 mb-3">View Record</h1>
                    <div class="form-group">
                        <label>Id</label>
                        <p><b><?php echo $row["ID_CLIENT"]; ?></b></p>
                    </div>
                    <div class="form-group">
                        <label>Nom</label>
                        <p><b><?php echo $row["NOM"]; ?></b></p>
                    </div>
                    <div class="form-group">
                        <label>Prenom</label>
                        <p><b><?php echo $row["PRENOM"]; ?></b></p>
                    </div>
					<div class="form-group">
                        <label>Date de naissance</label>
                        <p><b><?php echo $row["DATE_DE_NAISSANCE"]; ?></b></p>
                    </div>
					<div class="form-group">
                        <label>Date de l'inscription</label>
                        <p><b><?php echo $row["DATE_INSCRIPTION"]; ?></b></p>
                    </div>
				
                    <p><a href="CRUD.php" class="btn btn-primary">Back</a></p>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>	
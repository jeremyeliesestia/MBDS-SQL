<!DOCTYPE html>
<html lang="fr">

<head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
	<br>
	<br>
	<div style="text-align:center">
		<a href= "Welcome.php" class="btn btn-primary">
			Connection
		</a>
	</div>
</body>

<?php

// Create connection to Oracle
$conn = oci_connect("SCHOENDORFBZ2223", "SCHOENDORFBZ222301",
"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");

// Process delete operation after confirmation
if(isset($_POST["id"]) && !empty($_POST["id"])){

    $stid = oci_parse($conn,'DELETE FROM CLIENT WHERE ID_LIVRE = :id');
    $param_id = trim($_POST["id"]);
	oci_bind_by_name($stid,":id", $param_id);
	
	oci_execute($stid);  

	header("location: CRUD.php");     
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Livre</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5 mb-3">Delete Livre</h2>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="alert alert-danger">
                            <input type="hidden" name="id" value="<?php echo trim($_GET["id"]); ?>"/>
                            <p>Etes-vous sur de suppimer ce livre?</p>
                            <p>
                                <input type="submit" value="Yes" class="btn btn-danger">
                                <a href="CRUD.php" class="btn btn-secondary">No</a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
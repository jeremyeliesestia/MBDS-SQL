<!DOCTYPE html>
<html lang="fr">

<head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<form method="post">
    <br>
    <button class="btn btn-primary offset2" name="Clientele"> Clientèle </button>
    <br>
    <br>
    <button class="btn btn-primary offset2" name="Bibliotheque"> Bibliothèque</button>
    <br>
    <br>
    <button class="btn btn-primary offset2" name="Livres"> Livres</button>

    <br>
    <br>

    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-7 mb-5 clearfix">

                    <?php

					// Create connection to Oracle
					$conn = oci_connect("SCHOENDORFBZ2223", "SCHOENDORFBZ222301",
					"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");

                    echo "<br>";
                    if (isset($_POST['Clientele'])) {                    
                            
					// Attempt select query execution
					$stid = oci_parse($conn,'SELECT * FROM client');
					oci_execute($stid);
				
						echo '<table class="table table-bordered table-striped">';
							echo "<thead>";
								echo "<tr>";
									echo "<th>Id</th>";
									echo "<th>Nom</th>";
									echo "<th>Prenom</th>";
									echo "<th>Date de naissance</th>";
									echo "<th>Date d'inscription</th>";
								echo "</tr>";
							echo "</thead>";
							echo "<tbody>";
							
							while($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)){
								echo "<tr>";
									echo "<td>" . $row['ID_CLIENT'] . "</td>";
									echo "<td>" . $row['NOM'] . "</td>";
									echo "<td>" . $row['PRENOM'] . "</td>";       
									echo "<td>" . $row['DATE_DE_NAISSANCE'] . "</td>";  
									echo "<td>" . $row['DATE_INSCRIPTION'] . "</td>";  
								echo "</tr>";
							}
							echo "</tbody>";                            
						echo "</table>";
						
					}	
					echo "<br>";
					
					if (isset($_POST['Livres'])) {                    
							
						//Attempt select query execution
						$stid = oci_parse($conn,'SELECT * FROM LIVRE ');
						oci_execute($stid);
						
							echo '<table class="table table-bordered table-striped">';
								echo "<thead>";
									echo "<tr>";
										echo "<th>Id</th>";
										echo "<th>Titre</th>";
										echo "<th>Nombre de page</th>";
										echo "<th>Date d'emprunt</th>";
										echo "<th>Date max de rendu</th>";
									echo "</tr>";
								echo "</thead>";
								echo "<tbody>";
								
								while($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)){
									echo "<tr>";
										echo "<td>" . $row['ID_LIVRE'] . "</td>";
										echo "<td>" . $row['TITRE'] . "</td>";
										echo "<td>" . $row['NB_PAGE'] . "</td>";       
										echo "<td>" . $row['DATE_EMPRUNT'] . "</td>";  
										echo "<td>" . $row['DATE_MAX_RENDU'] . "</td>";  
									echo "</tr>";
								}
								echo "</tbody>";                            
							echo "</table>";					
					}
					
					if (isset($_POST['Bibliotheque'])) {                    
							
						//Attempt select query execution
						$stid = oci_parse($conn,'SELECT * FROM bibliotheque ');
						oci_execute($stid);
						
							echo '<table class="table table-bordered table-striped">';
								echo "<thead>";
									echo "<tr>";
										echo "<th>Id</th>";
										echo "<th>Adresse</th>";
										echo "<th>Nom</th>";
										echo "<th>Heure d'ouverture</th>";
										echo "<th>Heure de fermeture</th>";
									echo "</tr>";
								echo "</thead>";
								echo "<tbody>";
								
								while($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)){
									echo "<tr>";
										echo "<td>" . $row['ID_BIBLIOTHEQUE'] . "</td>";
										echo "<td>" . $row['ADRESSE'] . "</td>";
										echo "<td>" . $row['NOM_BIBLIOTHEQUE'] . "</td>";       
										echo "<td>" . $row['HEURE_OUVERTURE'] . "</td>";  
										echo "<td>" . $row['HEURE_FERMETURE'] . "</td>";  
									echo "</tr>";
								}
								echo "</tbody>";                            
							echo "</table>";					
					}
					
					// Close connection
					oci_close($conn);
                    ?>
					
                </div>        
            </div>
        </div>
    </div>
</div>

    <a href= "Welcome.php" class="btn btn-primary offset2">
        Retour
    </a>
	
</form>
</body>

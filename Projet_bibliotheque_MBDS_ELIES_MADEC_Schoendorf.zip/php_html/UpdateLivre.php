<?php
// Create connection to Oracle
$conn = oci_connect("SCHOENDORFBZ2223", "SCHOENDORFBZ222301",
"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");

// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
       
	$stid = oci_parse($conn,'UPDATE LIVRE SET TITRE= :titre, NB_PAGE= :nb_page , ETAT_STOCKAGE= :etat_stock ,
	DATE_EMPRUNT= :date_emprunt, DATE_MAX_RENDU= :date_max_emprunt, ETAT_EMPRUNT=:etat_emprunt WHERE ID_LIVRE = :id');
	
	oci_bind_by_name($stid,":titre", $_POST["titre"]);
	oci_bind_by_name($stid,":nb_page", $_POST["nb_page"]);
	oci_bind_by_name($stid,":etat_stock", $_POST["etat_stock"]);
	oci_bind_by_name($stid,":date_emprunt", $_POST["date_emprunt"]);
	oci_bind_by_name($stid,":date_max_emprunt", $_POST["date_max_emprunt"]);
	oci_bind_by_name($stid,":etat_emprunt", $_POST["etat_emprunt"]);
	oci_bind_by_name($stid,":id", $id);
	
	oci_execute($stid);

	header("location: CRUD.php");
	
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
		$stid = oci_parse($conn,'SELECT * FROM LIVRE WHERE ID_LIVRE = :id');
		$param_id = $id;
		oci_bind_by_name($stid,":id", $param_id);
		oci_execute($stid);
		$row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS);
                
		// Retrieve individual field value
		$id = $row["ID_LIVRE"];
		$titre = $row["TITRE"];
		$nb_page = $row["NB_PAGE"];	
		$etat_stock = $row["ETAT_STOCKAGE"];	
		$date_emprunt = $row["DATE_EMPRUNT"];	
		$date_max_emprunt = $row["DATE_MAX_RENDU"];	
		$etat_emprunt = $row["ETAT_EMPRUNT"];	
       
	}
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Livre</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Update Livre</h2>
                    <p>Modifier les informations des livres.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group">
                            <label>Titre</label>
                            <input type="text" name="titre" class="form-control" value="<?php echo $titre; ?>">
							</div>
                        <div class="form-group">
                            <label>Nombre de page</label>
                            <textarea name="nb_page" class="form-control"><?php echo $nb_page; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Stock de la bibliothèque</label>
                            <input type="text" name="etat_stock" class="form-control " value="<?php echo $etat_stock; ?>">
                        </div>
						<div class="form-group">
                            <label>Date de l'emprunt</label>
                            <input type="text" name="date_emprunt" class="form-control " value="<?php echo $date_emprunt; ?>">
                        </div>
						<div class="form-group">
                            <label>Date max de l'emprunt</label>
                            <input type="text" name="date_max_emprunt" class="form-control " value="<?php echo $date_max_emprunt; ?>">
                        </div>
						<div class="form-group">
                            <label>Etat de l'emprunt</label>
                            <input type="text" name="etat_emprunt" class="form-control " value="<?php echo $etat_emprunt; ?>">
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="CRUD.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
<?php

// Create connection to Oracle
$conn = oci_connect("SCHOENDORFBZ2223", "SCHOENDORFBZ222301",
"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	$stid = oci_parse($conn,'INSERT INTO LIVRE (TITRE, NB_PAGE, ETAT_STOCKAGE, DATE_EMPRUNT, DATE_MAX_RENDU, ETAT_EMPRUNT)
	VALUES( :titre, :nb_page, :etat_stock, :date_emprunt, :date_max_emprunt, :etat_emprunt)');
	
	oci_bind_by_name($stid,":titre", $_POST["titre"]);
	oci_bind_by_name($stid,":nb_page", $_POST["nb_page"]);
	oci_bind_by_name($stid,":etat_stock", $_POST["etat_stock"]);
	oci_bind_by_name($stid,":date_emprunt", $_POST["date_emprunt"]);
	oci_bind_by_name($stid,":date_max_emprunt", $_POST["date_max_emprunt"]);
	oci_bind_by_name($stid,":etat_emprunt", $_POST["etat_emprunt"]);
	
	header("location: CRUD.php");

	oci_execute($stid);  

}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ajouter Livre</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Ajouter Livre</h2>
                    <p>Ajouter un Livre.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group">
                            <label>Titre</label>
                            <input type="text" name="titre" class="form-control" >
                        </div>
                        <div class="form-group">
                            <label>Nombre de page</label>
                            <input type="text" name="nb_page" class="form-control ">
                        </div>
                        <div class="form-group">
                            <label>Etat des stock</label>
                            <input type="text" name="etat_stock" class="form-control">
                        </div>
						                        <div class="form-group">
                            <label>Date de l'emprunt</label>
                            <input type="text" name="date_emprunt" class="form-control">
                        </div>
						                        <div class="form-group">
                            <label>Date max de l'emprunt</label>
                            <input type="text" name="date_max_emprunt" class="form-control">
                        </div>                        <div class="form-group">
                            <label>Etat de l'emprunt</label>
                            <input type="text" name="etat_emprunt" class="form-control">
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="CRUD.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
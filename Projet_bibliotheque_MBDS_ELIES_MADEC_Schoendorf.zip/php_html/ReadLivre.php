<?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
	// Create connection to Oracle
	$conn = oci_connect("SCHOENDORFBZ2223", "SCHOENDORFBZ222301",
	"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");
    
    // Prepare a select statement
	$param_id = Trim($_GET["id"]);
	echo $param_id;
	$stid = oci_parse($conn,'SELECT * FROM LIVRE WHERE ID_LIVRE = :id');

	oci_bind_by_name($stid,":id", $param_id);

	oci_execute($stid);
	
	$row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS);
                
	// Retrieve individual field value
	$id = $row["ID_LIVRE"];
	$titre = $row["TITRE"];
	$nb_page = $row["NB_PAGE"];	
	$etat_stock = $row["ETAT_STOCKAGE"];	
	$date_emprunt = $row["DATE_EMPRUNT"];	
	$date_max_emprunt = $row["DATE_MAX_RENDU"];	
	$etat_emprunt = $row["ETAT_EMPRUNT"];	
}     

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-5 mb-3">View Record</h1>
                    <div class="form-group">
                        <label>Id</label>
                        <p><b><?php echo $row["ID_LIVRE"]; ?></b></p>
                    </div>
                    <div class="form-group">
                        <label>Titre</label>
                        <p><b><?php echo $row["TITRE"]; ?></b></p>
                    </div>
                    <div class="form-group">
                        <label>Nombre de pages</label>
                        <p><b><?php echo $row["NB_PAGE"]; ?></b></p>
                    </div>
					<div class="form-group">
                        <label>Stockage</label>
                        <p><b><?php echo $row["ETAT_STOCKAGE"]; ?></b></p>
                    </div>
					<div class="form-group">
                        <label>Date de l'emprunt</label>
                        <p><b><?php echo $row["DATE_EMPRUNT"]; ?></b></p>
                    </div>
					<div class="form-group">
                        <label>Date max du rendu</label>
                        <p><b><?php echo $row["DATE_MAX_RENDU"]; ?></b></p>
                    </div>
					<div class="form-group">
                        <label>Etat</label>
                        <p><b><?php echo $row["ETAT_EMPRUNT"]; ?></b></p>
                    </div>					
                    <p><a href="CRUD.php" class="btn btn-primary">Back</a></p>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>	
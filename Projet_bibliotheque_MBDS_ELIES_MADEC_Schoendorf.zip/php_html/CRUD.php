


<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">	
    <link rel="stylesheet" href="style.css">
</head>

<body>

     <div class="wrapper">
         <div class="container-fluid">
             <div class="row">
                 <div class="col-md-12">

                    <div class="mt-5 mb-3 clearfix">
                        <h2 class="pull-left">Livres</h2>
                        <a href="AjouterLivre.php" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Ajouter un livre</a>
                    </div>

                    <?php   
                    
					// Create connection to Oracle
					$conn = oci_connect("SCHOENDORFBZ2223", "SCHOENDORFBZ222301",
					"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");
                    
                    // Attempt select query execution
                    $stid = oci_parse($conn,'SELECT * FROM LIVRE ');
					oci_execute($stid);
					
					echo '<table class="table table-bordered table-striped">';
						echo "<thead>";
							echo "<tr>";
								echo "<th>Id</th>";
								echo "<th>Titre</th>";
								echo "<th>Nombre de page</th>";
								echo "<th>En stock</th>";
								echo "<th>Date d'emprunt</th>";
								echo "<th>Date max de rendu</th>";
								echo "<th>Emprunté</th>";
							echo "</tr>";
						echo "</thead>";
						echo "<tbody>";
						while($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)){
							echo "<tr>";
								echo "<td>" . $row['ID_LIVRE'] . "</td>";
								echo "<td>" . $row['TITRE'] . "</td>";
								echo "<td>" . $row['NB_PAGE'] . "</td>";
								echo "<td>" . $row['ETAT_STOCKAGE'] . "</td>";
								echo "<td>" . $row['DATE_EMPRUNT'] . "</td>";
								echo "<td>" . $row['DATE_MAX_RENDU'] . "</td>";
								echo "<td>" . $row['ETAT_EMPRUNT'] . "</td>";
								echo "<td>";
									echo '<a href="ReadLivre.php?id='. $row['ID_LIVRE'] .'" class="mr-3" title="View Record" data-toggle="tooltip"><span class="fa fa-eye"></span></a>';
									echo '<a href="updateLivre.php?id='. $row['ID_LIVRE'] .'" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa                                                                fa-pencil"></span></a>';
									echo '<a href="deleteLivre.php?id='. $row['ID_LIVRE'] .'" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
								echo "</td>";
							echo "</tr>";
						}
						echo "</tbody>";                            
					echo "</table>";
                    
                    ?>
                    </div>
                </div>
        </div>
    </div>

     <div class="wrapper">
         <div class="container-fluid">
             <div class="row">
                 <div class="col-md-12">

                    <div class="mt-5 mb-3 clearfix">
                        <h2 class="pull-left">Clients</h2>
                        <a href="AjouterClient.php" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Ajouter un client</a>
                    </div>

                    <?php                    
                    
                    // Attempt select query execution
                    $stid = oci_parse($conn,'SELECT * FROM client');
					oci_execute($stid);
                    
					echo '<table class="table table-bordered table-striped">';
						echo "<thead>";
							echo "<tr>";
								echo "<th>Id</th>";
								echo "<th>Nom</th>";
								echo "<th>Prenom</th>";
								echo "<th>Date de naissance</th>";
								echo "<th>Date d'inscription</th>";
							echo "</tr>";
						echo "</thead>";
						echo "<tbody>";
						while($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)){
							echo "<tr>";
								echo "<td>" . $row['ID_CLIENT'] . "</td>";
								echo "<td>" . $row['NOM'] . "</td>";
								echo "<td>" . $row['PRENOM'] . "</td>";       
								echo "<td>" . $row['DATE_DE_NAISSANCE'] . "</td>";  
								echo "<td>" . $row['DATE_INSCRIPTION'] . "</td>"; 
								echo "<td>";
									echo '<a href="ReadClient.php?id='. $row['ID_CLIENT'] .'" class="mr-3" title="View Record" data-toggle="tooltip"><span class="fa fa-eye"></span></a>';
									echo '<a href="UpdateClient.php?id='. $row['ID_CLIENT'] .'" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa                                                                fa-pencil"></span></a>';
									echo '<a href="DeleteClient.php?id='. $row['ID_CLIENT'] .'" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
								echo "</td>";
							echo "</tr>";
						}
						echo "</tbody>";                            
					echo "</table>"; 
                    
                    ?>
                    </div>
                </div>
        </div>
    </div>
    <div class="offset">
        <a href= "Welcome.php" class="btn btn-primary">
			Retour
        </a>
    </div>


</body>
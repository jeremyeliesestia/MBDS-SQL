<?php
// Create connection to Oracle
$conn = oci_connect("SCHOENDORFBZ2223", "SCHOENDORFBZ222301",
"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");

// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
       
	$stid = oci_parse($conn,'UPDATE CLIENT SET NOM = :nom , PRENOM = :prenom , DATE_DE_NAISSANCE = :date_naissance 
	, DATE_INSCRIPTION = :date_inscription WHERE ID_CLIENT = :id');
	
	$input_nom = $_POST["nom"];
	
	oci_bind_by_name($stid,":nom",$input_nom);
	oci_bind_by_name($stid,":prenom", $_POST["prenom"]);
	oci_bind_by_name($stid,":date_naissance", $_POST["date_naissance"]);
	oci_bind_by_name($stid,":date_inscription", $_POST["date_inscription"]);

	oci_bind_by_name($stid,":id", $id);
	
	oci_execute($stid);

	header("location: CRUD.php");
	
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
		$stid = oci_parse($conn,'SELECT * FROM CLIENT WHERE ID_CLIENT = :id');
		$param_id = $id;
		oci_bind_by_name($stid,":id", $param_id);
		oci_execute($stid);
		
		$row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS);
                
		// Retrieve individual field value
		$id = $row["ID_CLIENT"];
		$nom = $row["NOM"];
		$prenom = $row["PRENOM"];	
		$date_naissance = $row["DATE_DE_NAISSANCE"];	
		$date_inscription = $row["DATE_INSCRIPTION"];	
       
	}
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Client</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Update Client</h2>
                    <p>Modifier les informations des clients.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group">
                            <label>Nom</label>
                            <input type="text" name="nom" class="form-control" value="<?php echo $nom; ?>">
							</div>
                        <div class="form-group">
                            <label>Prenom</label>
                            <textarea name="prenom" class="form-control"><?php echo $prenom; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Date de naissance</label>
                            <input type="text" name="date_naissance" class="form-control " value="<?php echo $date_naissance; ?>">
                        </div>
						<div class="form-group">
                            <label>Date d'inscription</label>
                            <input type="text" name="date_inscription" class="form-control " value="<?php echo $date_inscription; ?>">
                        </div>

                        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="CRUD.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
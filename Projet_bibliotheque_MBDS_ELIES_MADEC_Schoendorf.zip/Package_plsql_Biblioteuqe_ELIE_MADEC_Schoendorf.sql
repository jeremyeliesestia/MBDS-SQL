---
create or replace package pk_bibliotheca is
TYPE refCursorType IS REF CURSOR;
function getBooks() return pk_bibliotheca.refCursorType ;
procedure insertBooks(li IN Livre%rowtype) ;
function getClients() return pk_bibliotheca.refCursorType ;
procedure insertClients(cl IN   Client%rowtype);
function getBibliotheques() return pk_bibliotheca.refCursorType ;
procedure insertBibliotheque(bi IN  Bibliotheque%rowtype);
end pk_bibliotheca;
/
create or replace package body pk_bibliotheca is
-- select qui ram�ne N Lignes
function getBooks() return pk_bibliotheca.refCursorType  IS
cursEmp pk_bibliotheca.refCursorType;
begin
    open cursEmp for
    select *
    FROM Livre 
    return  cursEmp ;
end getPiloteByAdr;
-- insert
procedure insertBooks(li IN Livre%rowtype) IS
begin
insert into Livre
values (li.id_livre#, li.id_auteur, li.titre, li.nb_page, li.nb_exemplaire);
end;
-- select qui ram�ne N Lignes
function getClients() return pk_bibliotheca.refCursorType  IS
cursEmp pk_bibliotheca.refCursorType;
begin
    open cursEmp for
    select *
    FROM Client 
    return  cursEmp ;
end getClients;
-- insert
procedure insertClients(cl IN   Client%rowtype) IS
begin
insert into Client
values (cl.id_client#, cl.id_bibliotheque, cl.nom, cl.prenom, cl.date_de_naissance);
end;
-- select qui ram�ne N Lignes
function getBibliotheques() return pk_bibliotheca.refCursorType  IS
cursEmp pk_bibliotheca.refCursorType;
begin
    open cursEmp for
    select *
    FROM Bibliotheque 
    return  cursEmp ;
end getBibliotheques;
-- insert
procedure insertBibliotheque(bi IN  Bibliotheque%rowtype) IS
begin
insert into Bibliotheque
values (bi.id_bibliotheque#, bi.id_ville, bi.adresse, bi.nom_bibliotheque, bi.heure_ouverture, bi.heure_fermeture);
end;
end pk_bibliotheca;
/